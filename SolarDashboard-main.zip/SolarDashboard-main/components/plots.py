import plotly.graph_objects as go
import plotly.express as px
import numpy as np

def create_time_series(data, model_name):
    """Create time series plot"""
    fig = go.Figure()

    fig.add_trace(go.Scatter(
        x=data['Time'],
        y=data['Actual'],
        name='Actual',
        line=dict(color='#1E88E5', width=2),
        hovertemplate='Time: %{x}<br>Actual: %{y:.4f} kW<extra></extra>'
    ))

    fig.add_trace(go.Scatter(
        x=data['Time'],
        y=data['Predicted'],
        name='Predicted',
        line=dict(color='#FFA726', width=2, dash='dash'),
        hovertemplate='Time: %{x}<br>Predicted: %{y:.4f} kW<extra></extra>'
    ))

    fig.update_layout(
        title=dict(
            text=f"Actual vs Predicted Values Over the Test Set - {model_name}",
            font=dict(size=24)  # Adjust title font size
        ),
        xaxis=dict(
            title=dict(text="Time (minutes)", font=dict(size=20)),  # X-axis title font size
            tickfont=dict(size=18),  # X-axis tick labels font size
            range=[0,550]
        ),
        yaxis=dict(
            title=dict(text="Solar Power (kW)", font=dict(size=20)),  # Y-axis title font size
            tickfont=dict(size=18)  # Y-axis tick labels font size
        ),
        legend=dict(
            font=dict(size=18)  # Legend font size
        ),
        hoverlabel=dict(
            font=dict(size=16)  # Hover text font size
        ),
        font=dict(size=18),  # Global font settings
        hovermode='x unified',
        showlegend=True,
        height=400,
        plot_bgcolor='white',
        paper_bgcolor='white'
    )

    return fig

def create_bar_comparison(data, model_name):
    """Create bar comparison plot"""
    fig = go.Figure()

    # Take first 5 points
    sample_data = data.head()

    fig.add_trace(go.Bar(
        x=sample_data.index,
        y=sample_data['Actual'],
        name='Actual',
        marker_color='#1E88E5'
    ))

    fig.add_trace(go.Bar(
        x=sample_data.index,
        y=sample_data['Predicted'],
        name='Predicted',
        marker_color='#FFA726'
    ))

    fig.update_layout(
        title="First 5 Points Comparison",
        xaxis_title="Time (minutes)",
        yaxis_title="Solar Power (kW)",
        barmode='group',
        height=300
    )

    return fig

def create_scatter_plot(data, model_name):
    """Create scatter plot with regression line"""
    fig = go.Figure()
    
    # Scatter plot
    fig.add_trace(go.Scatter(
        x=data['Actual'],
        y=data['Predicted'],
        mode='markers',
        marker=dict(color='#1E88E5'),
        name='Data Points'
    ))
    
    # Compute regression line
    slope, intercept = np.polyfit(data['Actual'], data['Predicted'], 1)
    regression_x = np.linspace(min(data['Actual']), max(data['Actual']), 100)
    regression_y = slope * regression_x + intercept
    
    # Regression line
    fig.add_trace(go.Scatter(
        x=regression_x,
        y=regression_y,
        mode='lines',
        line=dict(color='red', width=2),
        name='Regression Line'
    ))
    
    fig.update_layout(
        title=f"Actual vs Predicted ({model_name})",
        xaxis_title="Actual Values (kW)",
        yaxis_title="Predicted Values (kW)",
        height=300
    )
    
    return fig