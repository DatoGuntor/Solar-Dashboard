import streamlit as st
import plotly.graph_objects as go

"""number={'font': {'size': 20}, 'color':"#000000" 'suffix': ' kW' if max_val > 1 else ''},"""
def create_horizontal_slider(value, min_val=0, max_val=1):
    """Create a horizontal slider chart"""
    fig = go.Figure(go.Indicator(
        mode="number+gauge",
        value=value,
        number={'font': {'size': 18, 'color': "#000000"}, 'suffix': ' kW'},
        gauge={
            'shape': "bullet",
            'axis': {'range': [min_val, max_val]},
            'bar': {'color': "#1E88E5"},
            'bgcolor': "#E3F2FD",
            'steps': [{'range': [0, max_val], 'color': "#BBDEFB"}
            ],
        }
    ))

    fig.update_layout(
        height=35,
        margin=dict(l=10, r=10, t=10, b=10),
        paper_bgcolor='rgba(0,0,0,0)',
        plot_bgcolor='rgba(0,0,0,0)'
    )

    return fig

def display_metrics(metrics_data, selected_model):
    """Display performance metrics for the selected model"""
    model_metrics = metrics_data[metrics_data['Model'] == selected_model].iloc[0]

    st.markdown(
        f"<div style='color: #1E88E5; margin-bottom: 15px;'>"
        f"<h4 style='margin: 0;'>Performance Metrics - {selected_model}</h4>"
        f"</div>",
        unsafe_allow_html=True
    )

    # MAE Slider
    st.markdown(
        "<div style='background-color: #E3F2FD; padding: 15px; border-radius: 5px; margin-bottom: 10px;'>"
        "<h6 style='margin: 8px 0 -10px 0; color: #1E88E5;'>Mean Absolute Error (MAE)</h6>",
        unsafe_allow_html=True
    )
    fig_mae = create_horizontal_slider(
        model_metrics['MAE (kW)'],
        0,
        metrics_data['MAE (kW)'].max()
    )
    st.plotly_chart(fig_mae, use_container_width=True)
    st.markdown("</div>", unsafe_allow_html=True)

    # MSE Slider
    st.markdown(
        "<div style='background-color: #E3F2FD; padding: 15px; border-radius: 5px; margin-bottom: 10px;'>"
        "<h6 style='margin: 8px 0 -10px 0; color: #1E88E5;'>Mean Squared Error (MSE)</h6>",
        unsafe_allow_html=True
    )
    fig_mse = create_horizontal_slider(
        model_metrics['MSE (kW)'],
        0,
        metrics_data['MSE (kW)'].max()
    )
    st.plotly_chart(fig_mse, use_container_width=True)
    st.markdown("</div>", unsafe_allow_html=True)

    # RMSE Slider
    st.markdown(
        "<div style='background-color: #E3F2FD; padding: 15px; border-radius: 5px; margin-bottom: 10px;'>"
        "<h6 style='margin: 8px 0 -10px 0; color: #1E88E5;'>Root Mean Squared Error (RMSE)</h6>",
        unsafe_allow_html=True
    )
    fig_rmse = create_horizontal_slider(
        model_metrics['RMSE (kW)'],
        0,
        metrics_data['RMSE (kW)'].max()
    )
    st.plotly_chart(fig_rmse, use_container_width=True)
    st.markdown("</div>", unsafe_allow_html=True)

    # R² Slider
    st.markdown(
        "<div style='background-color: #E3F2FD; padding: 15px; border-radius: 5px; margin-bottom: 10px;'>"
        "<h6 style='margin: 8px 0 -10px 0; color: #1E88E5;'>R² Score</h6>",
        unsafe_allow_html=True
    )
    fig_r2 = create_horizontal_slider(
        model_metrics['R²'],
        0,
        1
    )
    st.plotly_chart(fig_r2, use_container_width=True)
    st.markdown("</div>", unsafe_allow_html=True)