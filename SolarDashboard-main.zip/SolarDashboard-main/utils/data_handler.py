import pandas as pd
import numpy as np
import streamlit as st

def load_metrics_data():
    """Load the metrics data from uploaded file or use default data"""
    if 'metrics_data' in st.session_state:
        return st.session_state.metrics_data

    # Default metrics data
    MODELS = [
        "U-LSTM", "M-LSTM (Wsensor)", "M-LSTM (Wsensor+MET)",
        "Bi-LSTM", "CNN", "GRU", "LSTM-CNN", "LSTM-GRU"
    ]

    return pd.DataFrame({
        "Model": MODELS,
        "MAE (kW)": [0.0275, 0.0379, 0.0375, 0.0408, 0.0813, 0.0338, 0.0847, 0.0352],
        "MSE (kW)": [0.0037, 0.0046, 0.0044, 0.0052, 0.0149, 0.0047, 0.0169, 0.005],
        "RMSE (kW)": [0.0611, 0.068, 0.0664, 0.072, 0.1219, 0.0688, 0.13, 0.0704],
        "R²": [0.94, 0.92, 0.92, 0.91, 0.75, 0.92, 0.73, 0.92],
    })

def load_sample_data(selected_model=None):
    """Load real data for a specific model"""
    if 'time_series_data_dict' in st.session_state and selected_model in st.session_state.time_series_data_dict:
        return st.session_state.time_series_data_dict[selected_model]

    # Map model names to their folder names
    folder_map = {
        'U-LSTM': 'Univariate LSTM',
        'M-LSTM (Wsensor)': 'M-LSTM (Wsensor)',
        'M-LSTM (Wsensor+MET)': 'M-LSTM (Wsensor+MET)',
        'Bi-LSTM': 'Bi-LSTM',
        'CNN': 'CNN',
        'GRU': 'GRU',
        'LSTM-CNN': 'LSTM-CNN',
        'LSTM-GRU': 'LSTM-GRU'
    }
    
    folder_name = folder_map[selected_model]
    base_path = f'DASHBOARD/{folder_name}'
    
    # Load time series data
    data = pd.read_csv(f'{base_path}/actual_vs_predicted_test_set.csv')
    data.columns = ['Actual', 'Predicted']
    data['Time'] = range(len(data))

    # Initialize the dictionary if it doesn't exist
    if 'time_series_data_dict' not in st.session_state:
        st.session_state.time_series_data_dict = {}

    # Store data for the selected model
    if selected_model:
        st.session_state.time_series_data_dict[selected_model] = data
        return st.session_state.time_series_data_dict[selected_model]

    return data

def process_uploaded_metrics(uploaded_file):
    """Process uploaded metrics CSV file"""
    try:
        df = pd.read_csv(uploaded_file)
        required_columns = ['Model', 'MAE (kW)', 'MSE (kW)', 'RMSE (kW)', 'R²']

        if not all(col in df.columns for col in required_columns):
            st.error('The uploaded file must contain these columns: ' + ', '.join(required_columns))
            return None

        st.session_state.metrics_data = df
        return df
    except Exception as e:
        st.error(f'Error processing the file: {str(e)}')
        return None

def process_uploaded_timeseries(uploaded_file, selected_model):
    """Process uploaded time series CSV file for a specific model"""
    try:
        df = pd.read_csv(uploaded_file)
        required_columns = ['Time', 'Actual', 'Predicted']

        if not all(col in df.columns for col in required_columns):
            st.error('The uploaded file must contain these columns: ' + ', '.join(required_columns))
            return None

        # Initialize the time series data dictionary if it doesn't exist
        if 'time_series_data_dict' not in st.session_state:
            st.session_state.time_series_data_dict = {}

        # Store the data for the selected model
        st.session_state.time_series_data_dict[selected_model] = df
        return df
    except Exception as e:
        st.error(f'Error processing the file: {str(e)}')
        return None