import plotly.graph_objects as go
import plotly.express as px
from plotly.subplots import make_subplots
import pandas as pd
import numpy as np

def create_model_comparison_plot(metrics_data, metric_name, colors):
    """
    Create a comparison bar plot for all models for a specific metric
    
    Args:
        metrics_data (pd.DataFrame): DataFrame containing model metrics
        metric_name (str): Name of the metric to compare
        colors (list): List of colors for each model
    """
    fig = go.Figure()
    
    fig.add_trace(go.Bar(
        x=metrics_data['Model'],
        y=metrics_data[metric_name],
        marker_color=[colors[i % len(colors)] for i in range(len(metrics_data))]
    ))
    
    fig.update_layout(
        title=f"Model Comparison - {metric_name}",
        xaxis_title="Models",
        yaxis_title=metric_name,
        height=400,
        xaxis_tickangle=-45,
        showlegend=False
    )
    
    return fig

def create_metric_heatmap(metrics_data):
    """
    Create a heatmap visualization of all metrics for all models
    
    Args:
        metrics_data (pd.DataFrame): DataFrame containing model metrics
    """
    metric_columns = ['MAE (kW)', 'MSE (kW)', 'RMSE (kW)', 'R²']
    
    # Normalize the metrics for better visualization
    normalized_data = metrics_data.copy()
    for col in metric_columns:
        if col != 'R²':  # For error metrics, lower is better
            normalized_data[col] = (metrics_data[col] - metrics_data[col].min()) / \
                                 (metrics_data[col].max() - metrics_data[col].min())
        else:  # For R², higher is better
            normalized_data[col] = metrics_data[col]
    
    fig = go.Figure(data=go.Heatmap(
        z=normalized_data[metric_columns].values,
        x=metric_columns,
        y=normalized_data['Model'],
        colorscale='RdYlBu_r',
        hoverongaps=False
    ))
    
    fig.update_layout(
        title="Model Performance Heatmap",
        height=400,
        xaxis_title="Metrics",
        yaxis_title="Models"
    )
    
    return fig

def create_performance_radar(metrics_data, selected_model):
    """
    Create a radar chart for the selected model's performance metrics
    
    Args:
        metrics_data (pd.DataFrame): DataFrame containing model metrics
        selected_model (str): Name of the selected model
    """
    model_data = metrics_data[metrics_data['Model'] == selected_model].iloc[0]
    
    # Normalize metrics for radar chart
    metrics = ['MAE (kW)', 'MSE (kW)', 'RMSE (kW)', 'R²']
    values = []
    for metric in metrics:
        if metric != 'R²':
            # Invert error metrics so that higher is better
            max_val = metrics_data[metric].max()
            values.append(1 - (model_data[metric] / max_val))
        else:
            values.append(model_data[metric])
    
    fig = go.Figure()
    
    fig.add_trace(go.Scatterpolar(
        r=values,
        theta=metrics,
        fill='toself',
        name=selected_model
    ))
    
    fig.update_layout(
        polar=dict(
            radialaxis=dict(
                visible=True,
                range=[0, 1]
            )
        ),
        showlegend=True,
        title=f"Performance Radar - {selected_model}"
    )
    
    return fig

def create_trend_analysis(data, window_size=7):
    """
    Create a trend analysis plot with moving averages
    
    Args:
        data (pd.DataFrame): Time series data
        window_size (int): Window size for moving average
    """
    fig = go.Figure()
    
    # Original data
    fig.add_trace(go.Scatter(
        x=data['Date'],
        y=data['Actual'],
        name='Actual',
        line=dict(color='#1E88E5', width=1)
    ))
    
    # Moving averages
    ma_actual = data['Actual'].rolling(window=window_size).mean()
    ma_predicted = data['Predicted'].rolling(window=window_size).mean()
    
    fig.add_trace(go.Scatter(
        x=data['Date'],
        y=ma_actual,
        name=f'{window_size}-day MA (Actual)',
        line=dict(color='#1E88E5', width=2)
    ))
    
    fig.add_trace(go.Scatter(
        x=data['Date'],
        y=ma_predicted,
        name=f'{window_size}-day MA (Predicted)',
        line=dict(color='#FFA726', width=2)
    ))
    
    fig.update_layout(
        title=f"Trend Analysis ({window_size}-day Moving Average)",
        xaxis_title="Date",
        yaxis_title="Solar Power Output (kW)",
        height=400,
        hovermode='x unified'
    )
    
    return fig

def create_error_distribution(data):
    """
    Create an error distribution plot
    
    Args:
        data (pd.DataFrame): Time series data
    """
    errors = data['Predicted'] - data['Actual']
    
    fig = go.Figure()
    
    fig.add_trace(go.Histogram(
        x=errors,
        nbinsx=30,
        name='Error Distribution',
        marker_color='#1E88E5'
    ))
    
    fig.update_layout(
        title="Prediction Error Distribution",
        xaxis_title="Prediction Error (kW)",
        yaxis_title="Frequency",
        height=300,
        showlegend=False
    )
    
    return fig

def create_combined_time_series(data_dict):
    """Create a combined time series plot with all models"""
    fig = go.Figure()
    
    # Add actual values
    fig.add_trace(go.Scatter(
        x=list(data_dict.values())[0]['Time'],
        y=list(data_dict.values())[0]['Actual'],
        name='Actual',
        line=dict(color='#1E88E5', width=2)
    ))
    
    # Color palette for different models
    colors = px.colors.qualitative.Set2
    
    # Add predicted values for each model
    for i, (model, data) in enumerate(data_dict.items()):
        fig.add_trace(go.Scatter(
            x=data['Time'],
            y=data['Predicted'],
            name=f'{model} (Predicted)',
            line=dict(color=colors[i % len(colors)], width=2, dash='dash')
        ))
    
    fig.update_layout(
        title="Combined Time Series Plot - All Models",
        xaxis_title="Time (minutes)",
        yaxis_title="Solar Power Output (kW)",
        hovermode='x unified',
        showlegend=True,
        height=400,
        xaxis=dict(range=[0, 500])
    )
    
    return fig

def create_metric_comparison_grid(metrics_data):
    """Create a grid of metric comparisons for all models"""
    fig = make_subplots(rows=1, cols=4,
                      subplot_titles=('MAE (kW)', 'MSE (kW)', 'RMSE (kW)', 'R² Score'))
    
    metrics = ['MAE (kW)', 'MSE (kW)', 'RMSE (kW)', 'R²']
    colors = px.colors.qualitative.Set3
    
    for i, metric in enumerate(metrics, 1):
        fig.add_trace(
            go.Bar(
                x=metrics_data['Model'],
                y=metrics_data[metric],
                marker_color=colors[i % len(colors)],
                showlegend=False
            ),
            row=1, col=i
        )
    
    fig.update_layout(
        height=400,
        title_text="Model Performance Metrics Comparison",
        title_x=0.5,
        xaxis_tickangle=-45,
        bargap=0.15
    )
    
    # Update layout for each subplot
    for i in range(1, 5):
        fig.update_xaxes(title_text="Models", row=1, col=i)
        fig.update_yaxes(title_text=metrics[i-1], row=1, col=i)
    
    return fig
